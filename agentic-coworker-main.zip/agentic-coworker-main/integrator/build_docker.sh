docker build -t ghcr.io/jingnanzhou/integrator:latest .
