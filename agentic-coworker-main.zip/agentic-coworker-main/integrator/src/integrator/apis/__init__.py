# This file makes Python treat the `annotation` directory as a package.
