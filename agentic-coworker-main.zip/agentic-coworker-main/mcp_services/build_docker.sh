docker build -t ghcr.io/jingnanzhou/mcp-services:latest .
