def main():
    print("Hello from support-services!")


if __name__ == "__main__":
    main()
