uv pip install -e .

python -m support_services.api_server
